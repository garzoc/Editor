var pass="pass"
var Git = require("git");

/*
 * http://stackoverflow.com/questions/5955891/has-anyone-implemented-a-git-clone-or-interface-library-using-nodejs
 * */

module.exports=new function(){
	
	
	/*Git("data");
	Git.init("garzoc");
	Git.pull("https://github.com/garzoc/test.git","master");
	Git.commit("test");
	/*http://stackoverflow.com/questions/5343068/is-there-a-way-to-skip-password-typing-when-using-https-on-github*/
	
	//Git.push("https://garzoc:"+pass+"@github.com/garzoc/test.git");

	
	var data=["caret",["rownumber"]];
	
	
	String.prototype.insert = function (string,index) {
		if (index > 0)
			return this.substring(0, index) + string + this.substring(index, this.length);
		else
			return string + this;
	}
	
	String.prototype.remove = function (pos,count) {
		return this.substring(0, pos) + this.substring(pos+count, this.length);	
	}
	
	
	this.passToEvents=function(string,client){
		var messageContext=JSON.parse(string);
		
		/*var node=data;
		var childNode=trm.child;
		while(childNode!=null){
			node=node[childNode.index];
			childNode=childNode.child;
		}*/
		//console.log(this[trm.Action]);
		//console.log(trm.string);
		
		if(messageContext.child===undefined)trm.child=client;
		
		if(messageContext.string==undefined)	
			if(this[messageContext.Action]!=undefined)
				this[messageContext.Action](trm.child,trm.Caret);
			else
				return 0;
		else
			this.addChar(messageContext.child,messageContext.Caret,trm.string);
			
			//console.log(data);
	}
	
	
	this.addNewTextBlock=function (event){
		data[event.index].push("");
		
		//console.log(data)
	}
	
	
	this.OnBlur=function(event){
		console.log("hi");
		if(data[event.index]!=null&& data[event.index][event.child.index]!=null)
		if(data[event.index][event.child.index]==="") data[event.index].splice(event.child.index,1);
	}
	
	this.OnTab=function(event,caret){
		//event=="banana";
		data[event.index][event.child.index]=data[event.index][event.child.index].insert("\t",caret);
		//console.log(event);
	}
	
	
	this.OnSpace=function(event,caret){
		
		data[event.index][event.child.index]=data[event.index][event.child.index].insert(" ",caret);
	}
	
	this.OnEnter=function(event,caret){
	//	console.log(data[event.index][event.child.index].insert("k",1));
		tmp=data[event.index][event.child.index];
		data[event.index][event.child.index]=data[event.index][event.child.index]=tmp.substring(0,caret);
		data.splice(event.index+1,0,["rownumber"]);
		tmp=tmp.substring(caret,tmp.length);
		data[event.index+1].push(tmp);
		while(data[event.index][event.child.index+1]!==undefined){
			data[event.index+1].push(data[event.index][event.child.index+1])
			data[event.index].splice(event.child.index+1,1);
		}
		//arr.splice(2, 0, "Lene");
		//data[event.index][event.child.index]=data[event.index][event.child.index].insert(" ",caret);
	}
	
	this.OnBackSpace=function(event,caret){
		//unkonw bugs in back space
		if (caret > 0){
			if(data[event.index][event.child.index]!=undefined) data[event.index][event.child.index]=data[event.index][event.child.index].remove(caret-1,1);
		}else if(event.child.index > 1){
			
			data[event.index][child.index-1]=data[event.index][child.index-1].remove(data[event.index][child.index-1].length-1,1);	
			
		}else if(event.index > 1){
			//console.log("anana");			
			for(var i=1;i<data[event.index].length;i++){
				if(data[event.index][event.child.index]!="") data[event.index-1].push(data[event.index][event.child.index]);
			}
			if(!(data[event.index-1].length > 1))  data[event.index-1].push("");
			data.splice(event.index,1);
		}
	}
	

	this.addChar=function(event,caret,string){
		data[event.index][event.child.index]=data[event.index][event.child.index].insert(string,caret);	
	}
	
	
	this.OnLoad=function(event){
		
		for(var i=1;i<data.length;i++){
			if(i>1)event.send('{"Action":"addRow","child":null,"Caret":0}');
			for(var n=1;n<data[i].length;n++){
				event.send('{"Action":"addNewTextBlock","child":{"index":'+i+',"child":null},"Caret":0}');
				event.send('{"string":"'+data[i][n]+'","child":{"index":'+i+',"child":{"index":'+n+',"child":null}},"Caret":0}');
			}
		}
	}
	
	this.OnArrowDown=function(event){
		event.index++;
		if(data[event.index]!=null && data[event.index][1]==null)		
			this.addNewTextBlock(event);
	}
	
	this.OnArrowUp=function(event){
		event.index--;
		if(data[event.index]!="caret" && data[event.index][1]==null)		
			this.addNewTextBlock(event);
		
	}

}
