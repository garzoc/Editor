/*function OnFocus(node,Caret){
	//Caret.setState("visible");
}

function OnBlur(node,Caret){
	//Caret.setState("hidden");
	//if(node!=null && node.innerHTML==="") node.parentElement.removeChild(node);
}*/

function OnClick(node,Caret,caretPos){
	Caret.setCaret(node,caretPos);
	editTextBlock(node);
}


function OnSpace(node,Caret){
	var caretPos=Caret.getCaretPos();
	/*if(!theme.isKeyword(node.innerHTML.substring(0,caretPos)) && !theme.isKeyword(node.innerHTML.substring(caretPos,node.innerHTML.length))){
		node.innerHTML=node.innerHTML.insert(" ",caretPos);
		Caret.setCaret(node,++caretPos);
	}else{
		node=splitEditBlock(node,caretPos);
		var str=node.innerHTML;
		node.innerHTML=str.insert(" ",0);
		Caret.setCaret(node,1);	
	}*/
	
	node.innerHTML=node.innerHTML.insert(" ",caretPos);
	Caret.setCaret(node,++caretPos);
	
	var str=node.innerHTML.split(/\s+/);
	var sum=0;
	var caretAlreadyMoved=false;//the caret should only be moved once testtest -> test test
	for(var i=0;i<str.length ; i++){
		if(theme.isKeyword(str[i])){
			node=splitEditBlock(node,sum);
			node=splitEditBlock(node,1+str[i].length);
			if(!caretAlreadyMoved){
				if(caretPos-sum <= node.previousSibling.innerHTML.length){
					Caret.setCaret(node.previousSibling,caretPos-sum);
					editTextBlock(node.previousSibling);
				}else{
					Caret.setCaret(node,1);
					editTextBlock(node);
				}
				caretAlreadyMoved=true;
			}
		}
		sum=sum+(str[i].length)+1;
	}
	setHighlight(node);
}


function OnTab(node,Caret){
	var caretPos=Caret.getCaretPos();
	/*if(!textBlockIsKeyword(node)){
		node.innerHTML=node.innerHTML.insert("\t",caretPos);
		Caret.setCaret(node,++caretPos);
	}else{
		var newNode=splitEditBlock(node,caretPos);
		var str=newNode.innerHTML;
		newNode.innerHTML=str.insert("\t",0);
		Caret.setCaret(newNode,1);	
	}*/
	
	node.innerHTML=node.innerHTML.insert("\t",caretPos);
	Caret.setCaret(node,++caretPos);
	
	var str=node.innerHTML.split(/\s+/);
	var sum=0;
	for(var i=0;i<str.length ; i++){
		if(theme.isKeyword(str[i])){
			node=splitEditBlock(node,sum);
			node=splitEditBlock(node,1+str[i].length);
			if(caretPos-sum <= node.previousSibling.innerHTML.length){
				Caret.setCaret(node.previousSibling,caretPos-sum);
				editTextBlock(node.previousSibling);
			}else{
				Caret.setCaret(node,1);
				editTextBlock(node);
			}
		}
		sum=sum+(str[i].length)+1;
	}
	setHighlight(node);
	
}

function OnEnter(node,Caret){


	insertRow(node.parentElement);
	
	var nextNode=splitEditBlock(node,Caret.getCaretPos());
	while((nextNode.nextSibling)!=null){
		nextNode=nextNode.nextSibling;
		nextNode.parentElement.nextSibling.appendChildTwice(nextNode.previousSibling);
		nextNode.parentElement.removeChild(nextNode.previousSibling);
	}
	
	nextNode.parentElement.nextSibling.appendChildTwice(nextNode.parentElement.lastChild);
	Caret.setCaret(nextNode.parentElement.nextSibling.children[0],0);
	editTextBlock(nextNode.parentElement.nextSibling.children[0]);
	if(nextNode.parentElement!==null)
		nextNode.parentElement.removeChild(nextNode.parentElement.lastChild);
			
}


function OnArrowLeft(node,Caret){
	var caretPos=Caret.getCaretPos();
	if (caretPos > 0) {
		Caret.setCaret(node,--caretPos);
	}else if(node.previousSibling!=undefined){
		Caret.setCaret(node.previousSibling,node.previousSibling.innerHTML.length-1);
		editTextBlock(node.previousSibling);
	}
	//console.log(Caret.getCaretPos());
}


function OnArrowRight(node,Caret){
	var caretPos=Caret.getCaretPos();
	if(caretPos < node.innerHTML.length) {
		Caret.setCaret(node,++caretPos);
	} else if(node.nextSibling!==null){
		Caret.setCaret(node.nextSibling,1);
		editTextBlock(node.nextSibling);
	}
	//console.log(Caret.getCaretPos());
}





function OnBackSpace(node,Caret){
	var caretPos=Caret.getCaretPos();
	//console.log(node.innerHTML);
	if (caretPos > 0){
		node.innerHTML=node.innerHTML.remove(--caretPos,1);
		Caret.setCaret(node,caretPos);
		
	}else if(node.previousSibling!=null){
		caretPos=node.previousSibling.innerHTML.length;	
		var prevNode=node.previousSibling;
		Caret.setCaret(prevNode,--caretPos);
		prevNode.innerHTML=prevNode.innerHTML.remove(caretPos,1);
		editTextBlock(prevNode);
		if(node!=null && prevNode!=null){
			if(!theme.isKeyword(prevNode.innerHTML) && !theme.isKeyword(node.innerHTML)){
				node=mergeTextBlock(prevNode,node);
			}else{
				node=prevNode;
			}
		}
		
	}else if(node.parentElement.previousSibling!=undefined && node.previousSibling==undefined){					
		var parent=node.parentElement;
		if(!(parent.previousSibling.children.length>1)){ 
			addNewTextBlock(parent.previousSibling,Caret);	
		}
		if(parent.previousSibling.children.length>0)
			node=parent.previousSibling.children[parent.previousSibling.children.length-1];
			
		Caret.setCaret(parent.previousSibling.lastChild,-1);
		editTextBlock(parent.previousSibling.lastChild);
		while(0<parent.children.length){
			parent.previousSibling.appendChildTwice(parent.children[0]);
			parent.removeChild(parent.children[0]);
		}
		removeRow(parent);
	}
	
	if(!isWhiteSpace(node.innerHTML.charAt(0)) && node.previousSibling!=null){
			var lastCharPrevNode=node.previousSibling.innerHTML.charAt(node.previousSibling.innerHTML.length-1);
			if(!isWhiteSpace(lastCharPrevNode)){
				caretPos=node.previousSibling.innerHTML.length;
				node=mergeTextBlock(node.previousSibling,node);
				
				Caret.setCaret(node,caretPos);
				editTextBlock(node);
			}
			
		}
		if(!isWhiteSpace(node.innerHTML.charAt(node.innerHTML.length-1)) && node.nextSibling!=null && !isWhiteSpace(node.nextSibling.innerHTML.charAt(0))){
			node=mergeTextBlock(node,node.nextSibling);
		}
		
		setHighlight(node);
}





function OnArrowUpDown(node,targetRow,Caret){
	if(targetRow.children[0]===undefined){
		addNewTextBlock(targetRow,Caret);
		Caret.setCaret(targetRow.lastChild,-1);
		editTextBlock(targetRow.lastChild);
		return 0;
	}
			
	var caretRect=Caret.getElement().getBoundingClientRect();
	var x2 = caretRect.left;
	var rect=targetRow.lastChild.getBoundingClientRect();
	var x=rect.left;
	if(x2 > x+targetRow.lastChild.scrollWidth){
		Caret.setCaret(targetRow.lastChild,-1);
		editTextBlock(targetRow.lastChild);
		return 0
	}
			
			
	for(var i=0;i<targetRow.children.length;i++){	
		rect = targetRow.children[i].getBoundingClientRect();
		x = rect.left;
					
		if((x2-x) <= (x+node.scrollWidth)){
			Caret.setCaret(targetRow.children[i],Caret.getCaretPos());
			editTextBlock(targetRow.children[i]);
			break;
		}
				//console.log(x+"    "+x2);	
	}
	
}

function OnArrowUp(node,Caret){
	OnArrowUpDown(node,node.parentElement.previousSibling,Caret);
	
}

function OnArrowDown(node,Caret){
	OnArrowUpDown(node,node.parentElement.nextSibling,Caret);
}



function OnAddChar(node,char,C){
	

	var oldstr=node.innerHTML;
	var caretPos=C.getCaretPos();
	
	if(isWhiteSpace(oldstr.charAt(caretPos-1)) && theme.isKeyword(oldstr.substring(0,caretPos))){//cut string important
		node=splitEditBlock(node,caretPos);
		caretPos=0;
		oldstr=node.innerHTML;
		C.setCaret(node,0);
		editTextBlock(node);
	}
			
	node.innerHTML=node.innerHTML.insert(char,caretPos);
	editTextBlock();

	/*for(var c in remoteCaret){//caret move code
		if(remoteCaret[c].getNode().parentElement.getIndex()==C.getNode().parentElement.getIndex()){
			remoteCaret[c].setCaret(remoteCaret[c].getNode(),remoteCaret[c].getCaretPos()+1);
		}
	}*/
	
	if(oldstr.length<node.innerHTML.length){//move caret as text is added
		caretPos++;
		C.setCaret(node,caretPos);
		editTextBlock(node);
	}
	
	/*if(isWhiteSpace(oldstr.charAt(caretPos-1)) && theme.isKeyword(oldstr.substring(caretPos,oldstr.length))){//uncomment if any bugs appear
		node=splitEditBlock(node,caretPos);
		C.setCaret(node.previousSibling,-1);
		editTextBlock(node.previousSibling);
	}*/
	
	
	if(!isWhiteSpace(node.innerHTML.charAt(0)) && node.previousSibling!=null){//merger node with previous node if white space is missign
		var lastCharPrevNode=node.previousSibling.innerHTML.charAt(node.previousSibling.innerHTML.length-1);
		if(!isWhiteSpace(lastCharPrevNode)){
			caretPos=node.previousSibling.innerHTML.length;
			node=mergeTextBlock(node.previousSibling,node);
			C.setCaret(node,caretPos+1);
			editTextBlock(node);
			
		}
	}
	
	if(!isWhiteSpace(node.innerHTML.charAt(node.innerHTML.length-1)) && node.nextSibling!=null){//merger node with next node if white space is missign
		var lastCharNextNode=node.nextSibling.innerHTML.charAt(0);
		if(!isWhiteSpace(lastCharNextNode) && node.nextSibling.innerHTML!=""){
			//console.log(node.innerHTML +"   |   " +node.nextSibling.innerHTML);
			caretPos=node.innerHTML.length;
			node=mergeTextBlock(node,node.nextSibling);
			C.setCaret(node,caretPos);
			editTextBlock(node);
			
		}
	}
	

	var start=1;
	var end=0;
	for(var i=0;i<node.innerHTML.length;i++){
		if(!isWhiteSpace(node.innerHTML.charAt(caretPos+end)) && (caretPos+end) <node.innerHTML.length)end++;
		if(!isWhiteSpace(node.innerHTML.charAt(caretPos-start)) && (caretPos-start)>=0)start++;
	}
	if(theme.isKeyword(node.innerHTML.substring(caretPos-(--start),caretPos+(end)))){
		node=splitEditBlock(node,caretPos-start);
		if(node.innerHTML.length!=(caretPos+end)-(caretPos-start)){
			node=splitEditBlock(node,(caretPos+end)-(caretPos-start));
			C.setCaret(node.previousSibling,caretPos-(caretPos-start));
			
			editTextBlock(node.previousSibling);//should be put after setCaret
			
		}else{
			C.setCaret(node,caretPos-(caretPos-start));
			editTextBlock(node);
		}
		
		
	}
	
	
	setHighlight(node);
	
	
}
