

/*
 * http://perfectionkills.com/whats-wrong-with-extending-the-dom/
 * 
 * */

function loadDOMExtension(){
	
	Element.prototype.appendChildren=function(node,count){
		for(var i=0;i<count;i++){
			this.appendChildTwice(node);
		}
	}
	
	Element.prototype.appendChildTwice=function(node){
		
		var newNode=node.cloneNode();
		newNode.innerHTML=node.innerHTML;
		node.copyEvents(newNode);
		this.appendChild(newNode);
		/*if(newNode.useFocus){
			this.lastChild.focus();
		}*/
	}
	/*
	 * 
	 * http://stackoverflow.com/questions/36635392/how-to-appendchildelement-many-times-the-same-element#36635432
	 * */
	Element.prototype.insertBeforeTwice=function(node,nextSibling){
		var newNode=node.cloneNode();
		newNode.innerHTML=node.innerHTML;
		if(node.boundListeners!==undefined){
			for(k in node.boundListeners){
				newNode.bindEventListener(k,node.boundListeners[k]);
			}

		}
		this.insertBefore(newNode,nextSibling);
	}
	
	Element.prototype.copyEvents=function (node){
		if(this.boundListeners!==undefined){
			for(k in this.boundListeners){
				node.bindEventListener(k,this.boundListeners[k]);
				//console.log("hello");
				//node.boundListeners[k](10);
			}
		}
		for(var i=0;i<this.children.length;i++){
			this.children[i].copyEvents(node.children[i]);
		}
	}
	
	Element.prototype.bindEventListener=function(event,func){
		this.addEventListener(event,func);
		if(this.boundListeners==undefined)this.boundListeners={};
		this.boundListeners[event]=func;

	}
	
	Element.prototype.getIndex=function(){
		var i=0;
		var node=this;
		while((node=node.previousElementSibling)!==null)i++;
		return i;
	}
	
	/*Element.prototype.doFocus=function(){
		this.useFocus=true;
	}*/
	
	String.prototype.insert = function (string,index) {
		if (index > 0)
			return this.substring(0, index) + string + this.substring(index, this.length);
		else
			return string + this;
	}
	
	String.prototype.remove = function (pos,count) {
		return this.substring(0, pos) + this.substring(pos+count, this.length);
		
	}
	
	
	
}

