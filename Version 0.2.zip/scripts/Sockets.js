var socket=null;

function initSocket(){
	//socket=new WebSocket("ws://127.0.0.1:8000/IDE");
	socket=new WebSocket("ws://192.168.1.4:8000/IDE");
	socket.onopen=function(e){
		console.log("Establishing contact");
		//send("OnLoad",-1);
		
	};

	socket.onmessage=function(e){
		var messageContext=JSON.parse(e.data);
		

		
		if(messageContext.Action!=undefined)
			processMessage(messageContext);
	};

	socket.onclose=function(){
		var test=setTimeout(function(){
			initSocket();
			//socket=new WebSocket("ws://192.168.1.4:8000/IDE");
		},1000)
		console.log("quit");
	};
}

/*function cloneObject(obj){
	var newObj=new Object;
	if(obj===null) return null;		
	for(k in obj)
		newObj[k]=obj[k];
	return newObj;
}*/

function send(Action,Node,Character){
	var messageContext=new Object;
	messageContext.ID="TESTER";
	messageContext.Action=Action;
	//console.log(Action+" - "+Node);
	if(Node!=null){ 
		messageContext.Row=Node.parentElement.getIndex();
		
		var sum=0;
		var nodeindex=Node.getIndex();
		for(var i=0;i<nodeindex;i++){
			sum=sum+Node.parentElement.children[i].length;
		}
		messageContext.test=sum;
		messageContext.textBlockIndex=Node.getIndex();
		messageContext.CaretPosition=localCaret.getCaretPos();
		
		
		messageContext.Char=Character;
		//console.log("added");
	}
	
	socket.send(JSON.stringify(messageContext));
}


function processMessage(messageContext){
	//console.log("banaana "+messageContext.Action);
	if(messageContext.Row!=undefined && messageContext.Row!=null){
	//console.log("Action  "+messageContext.Action);
	//	console.log("hello "+messageContext.Row+" - "+messageContext.textBlockIndex);
		//console.log(messageContext.test);
		var row=textContainer.children[messageContext.Row];
		var textBlock=row.children[messageContext.textBlockIndex];
		var caret=acquireRemoteCaret(messageContext.ID);
		caret.setState("visible");
	
		if(window[messageContext.Action]!=undefined){
			if(messageContext.Action=="OnAddChar")
				window[messageContext.Action](textBlock,messageContext.Char,caret);
			else if(messageContext.Action=="addNewTextBlock")
				window[messageContext.Action](row,caret);
			else if(messageContext.Action=="OnClick")
				window[messageContext.Action](textBlock,caret,messageContext.CaretPosition);
			else
				window[messageContext.Action](textBlock,caret);
		}else{
			console.log("ERROR: Event "+messageContext.Action+" not found");
		}
	}
}

