var standardServerPort=8000;
var startingRows=4;
var useServer=false;
var EditorTheme="Test";




var Caret=function(){
	var caret=document.createElement('div');
	caret.setAttribute("class","caret");
	var currentNode;
	
	var positionInTextBlock=0;
	
	this.setCaret=function setCaret(node,textPosition){
		caret.style.top=node.offsetTop+"px";
		//if(currentNode!=undefined)console.log("current "+currentNode.getIndex()+" | nextr "+node.getIndex());
		if(currentNode!=undefined && currentNode.parentElement!=null && currentNode.getIndex()!=node.getIndex() && currentNode.innerHTML=="")currentNode.parentElement.removeChild(currentNode);
		currentNode=node;
		//console.log(node.innerHTML);
		
		if(textPosition===-1){
			caret.style.left=(node.offsetLeft+node.scrollWidth)+"px"
			positionInTextBlock=node.innerHTML.length;
		}else{
			strLengthTest.innerHTML=node.innerHTML.substring(0,textPosition);
			caret.style.left=(node.offsetLeft+strLengthTest.scrollWidth)+"px";
			positionInTextBlock=textPosition;
		}
	};
	this.getNode=function(){
		return currentNode;
	}
	this.getCaretPos=function(){return positionInTextBlock;};
	
	this.setState=function(visibility){caret.style.visibility=visibility;}
	
	this.getElement=function(){return caret;};
}

function editTextBlock(node){
	if(localCaret.getNode()!=undefined)localCaret.getNode().focus();
	//node.focus();
}

var rowCount=0;
var localCaret=new Caret();
var remoteCaret= {};
//remoteCaret["qw"]=4;
var theme=new ThemeManager();

/*
 * LOADING/CREATING DOM ELEMENTS
 */
var textField=document.getElementsByClassName("text")[0];
var strLengthTest=document.getElementById("testStringLength");

var rowNumberContainer=document.createElement("div");
rowNumberContainer.setAttribute("id","rowNumberContainer");
textField.appendChild(rowNumberContainer);

var textContainer=document.createElement("div");
textContainer.setAttribute("id","textContainer");
textField.appendChild(textContainer);

var textRow=rowcount=document.createElement('div');
	textRow.setAttribute("class","text_row");

var rowNumber=document.createElement("span");
	rowNumber.setAttribute("class","row_number");
	
	//textRow.appendChild(rowNumber);

var textBlock=document.createElement('span');
	textBlock.setAttribute("class","text_block");
	textBlock.setAttribute("tabindex","-1");//allows the div to focused
	


//http://stackoverflow.com/questions/3656467/is-it-possible-to-focus-on-a-div-using-javascript-focus-function#3656524



//var caret=document.createElement('div');
	//caret.setAttribute("class","caret");
	



/*
 *======================================
 */

window.onload=function(){
	loadDOMExtension();
	theme.loadTheme(EditorTheme);
	bindEvents();
	//textField.appendChild(caret);
	
	textField.appendChild(localCaret.getElement());
	
	
	for(var i=0;i<startingRows;i++){
		addRow();
	}
	
	if(useServer)initSocket();
	
	
}


function addRow(){
	textContainer.appendChildTwice(textRow);
	rowNumberContainer.appendChildTwice(rowNumber);
}

function insertRow(node){
	if(node.nextSibling!=null){
		node.parentElement.insertBeforeTwice(textRow,node.nextSibling);
		rowNumberContainer.appendChildTwice(rowNumber);
	}else
		addRow();
}

function removeRow(node){
	
	node.parentElement.removeChild(node);
	rowNumberContainer.removeChild(rowNumberContainer.firstChild);
}

function addNewTextBlock(node,Caret){
	textBlock.innerHTML="";
	node.appendChildTwice(textBlock);
	Caret.setCaret(node.lastChild,-1);
	return node.lastChild;
	

}

function splitEditBlock(node,position){
	var newstr=node.innerHTML.substring(position,node.innerHTML.length);//changes when implementing collaboration
	
	node.innerHTML=node.innerHTML.substring(0,position);
	textBlock.innerHTML=newstr;
	var nextNode;
	
	if(node.nextSibling!==undefined&&node.nextSibling!==null){
		
		node.parentElement.insertBeforeTwice(textBlock,node.nextSibling);
		nextNode=node.nextSibling;
		//node.nextSibling.focus();
	}else{
		node.parentElement.appendChildTwice(textBlock);
		nextNode=node.parentElement.lastChild;
		//node.parentElement.lastChild.focus();
		
		
	}
	setHighlight(node);
	setHighlight(nextNode);
	return nextNode;

}

function mergeTextBlock(Head,Tail){
	if(Head!=null && Tail!=null){
		Head.innerHTML=Head.innerHTML+Tail.innerHTML;
		if(Tail.parentElement!=null)Tail.parentElement.removeChild(Tail);
		setHighlight(Head);
		return Head;
	}
	return null;
}



function closeEditBlock(node){
	if(node.value!=""){
		textBlock.innerHTML=node.innerHTML.replace(/</g, "&lt;").replace(/>/g, "&gt;");;
		node.parentElement.insertBeforeTwice(textBlock,node.nextSibling);
		node.parentElement.removeChild(node);
	}else{
		node.parentElement.removeChild(node);
	}
}



function acquireRemoteCaret(ID){
	if(remoteCaret[ID]==undefined){
		remoteCaret[ID]=new Caret();
		textField.appendChild(remoteCaret[ID].getElement());
	}
		
	return remoteCaret[ID];
}


function getDefaultEditorTextColor(){
	var color =theme.getDefaultTextColor();
	if(color==undefined) return "#FFFFFF";
	return color;

}

function textBlockIsKeyword(node){
	console.log(RGBtoHex(node.style.color)+"    "+getDefaultEditorTextColor())
	if(RGBtoHex(node.style.color)!=getDefaultEditorTextColor())return true;
	return false;
	
}

function setHighlight(node){
	var syntaxcolor=theme.getColorHighlight(node.innerHTML.trim());
	if(syntaxcolor!=undefined){
		node.style.color=syntaxcolor;
	}else{
		node.style.color=getDefaultEditorTextColor();
	}

}

function isWhiteSpace(str){
	if(str.length>0 && str.trim()=="") return true;
	return false;

}

function RGBtoHex(RGB) {
    if (/^#[0-9A-F]{6}$/i.test(RGB)) return RGB;
    RGB = RGB.match(/^rgb\((\d+),\s*(\d+),\s*(\d+)\)$/);
    function Hex(x) {
        return ("0" + parseInt(x).toString(16)).slice(-2);
    }
    return "#" + (Hex(RGB[1]) + Hex(RGB[2]) + Hex(RGB[3])).toUpperCase();
}




/*
 * http://stackoverflow.com/questions/7444451/how-to-get-the-actual-rendered-font-when-its-not-defined-in-css
 * http://stackoverflow.com/questions/118241/calculate-text-width-with-javascript
 * http://www.w3schools.com/tags/canvas_measuretext.asp
 * */

function getStringWidth(node,string) {
	console.log("nnooooooo");
    // re-use canvas object for better performance
    var canvas = getTextWidth.canvas || (getTextWidth.canvas = document.createElement("canvas"));
    var context = canvas.getContext("2d");
    context.font = getComputedStyle(node)['font-size']+" "+getComputedStyle(node)['font-family'];
    //console.log("hello"+);
    var metrics = context.measureText(string);
    return metrics.width;
}

function getTextWidth(node) {
    // re-use canvas object for better performance
    var canvas = getTextWidth.canvas || (getTextWidth.canvas = document.createElement("canvas"));
    var context = canvas.getContext("2d");
    context.font = getComputedStyle(node)['font-size']+" "+getComputedStyle(node)['font-family'];
    var metrics = context.measureText(node.innerHTML);
    return metrics.width;
}




