var ThemeManager=function(){
	var ThemeContext=null;

	this.loadTheme=function(name){
	
		var File = new XMLHttpRequest();
		File.responseType='text';
		File.open("GET", "Themes/"+name.trim()+".rdb", true);
		File.onreadystatechange = function() {
			if (File.readyState === 4) {
				if(File.status === 200 || File.status == 0){
					var fileContent = File.responseText;
					ThemeContext=JSON.parse(fileContent) 
				}
			}
		}
		File.send();
	};
	
	
	this.isKeyword=function(keyword){
		
		return ThemeContext.keywords[keyword.trim()]!=undefined;
	}
	
	this.getColorHighlight=function(keyword){
		return ThemeContext.keywords[keyword.trim()];
	
	};
	
	this.getDefaultTextColor=function(){
		return ThemeContext["DefaultTextColor"];
	};

}
