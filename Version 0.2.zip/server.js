var ws=require('ws').Server;
var events=require("./serverEvents");
var socketServer;
var portfinder=require('portfinder');//https://github.com/indexzero/node-portfinder
var clientList=[];
portfinder.basePort=8000;


portfinder.getPort(function (err, freePort) {
	socketServer=new ws({port:freePort});
	console.log("initiating server at "+freePort+"");
	
	socketServer.on('connection',function(client){
		console.log("welcome");
		client.listId=clientList.length;
		clientList.push(client);
	
		client.on('message', function (message) {
		
			//events.passToEvents(message.toString(),this);
		
			for(var i=0;i<clientList.length;i++){
				if(i!==this.listId)clientList[i].send(message.toString());
			}
		
		});

		client.on('close',function close(){
			for(var i=this.listId+1;i<clientList.length;i++){
				clientList[i].listId--;
			}
			clientList.splice(this.listId,1);
		});
	
	});

});

